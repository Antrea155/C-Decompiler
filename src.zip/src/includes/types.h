#ifndef DECOMPILER_TYPES_H
#define DECOMPILER_TYPES_H


#include <stdint.h>
#include <stddef.h>

/* Defining the types used */


typedef int64_t address;
typedef signed char  int8_t;
typedef signed short int16_t;
typedef signed int   int32_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;
typedef signed long long   int64_t;
typedef unsigned long long uint64_t;

#endif 
